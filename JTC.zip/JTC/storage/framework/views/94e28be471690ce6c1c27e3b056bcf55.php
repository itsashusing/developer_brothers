
<?php $__env->startSection('title'); ?>
Fo/activeFo
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div>
    
    
    <div class="box">
        <div class="box-header">
            <h3 class="box-title">Active Fo Data Table</h3>
        </div><!-- /.box-header -->
        <div class="box-body table-responsive">
            <table id="example2" class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Adhar</th>
                        <th>Pan</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $fo_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($fo->name); ?></td>
                        <td><?php echo e($fo->email); ?></td>
                        <td><?php echo e($fo->mobile); ?></td>
                        <td> <?php echo e($fo->adhar); ?></td>
                        <td><?php echo e($fo->pan); ?></td>
                        
                        <td><a href="">
                                <div class="form-check form-switch">
                                    <input class="form-check-input " type="checkbox" <?php if($fo->status == 1): ?> checked
                                    <?php endif; ?>
                                    onchange="changeStatus(<?php echo e($fo->id); ?>)" role="switch"
                                    id="flexSwitchCheckDefault">
                                    <label class="form-check-label" for="flexSwitchCheckDefault"></label>
                                </div>
                            </a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>


            </table>
            <div class="d-flex justify-content-end mt-2">

                <div>


                    <?php if($fo_data->lastPage() > 1): ?>
                    <ul class="pagination">
                        <li class="<?php echo e(($fo_data->currentPage() == 1) ? 'disabled' : ''); ?>">
                            <a class="btn btn-primary btn-sm me-1" href="<?php echo e($fo_data->url(1)); ?>">First</a>
                        </li>
                        <?php for($i = 1; $i <= $fo_data->lastPage(); $i++): ?>
                            <li class="">
                                <a class="btn btn-primary btn-sm me-1 <?php echo e(($fo_data->currentPage() == $i) ? 'active' : ''); ?>"
                                    href="<?php echo e($fo_data->url($i)); ?>"><?php echo e($i); ?></a>
                            </li>
                            <?php endfor; ?>

                            <li>
                                <a class="btn btn-primary btn-sm mx-1 <?php echo e(($fo_data->currentPage() == $fo_data->lastPage()) ? 'disabled' : ''); ?>"
                                    href="<?php echo e($fo_data->url($fo_data->currentPage() + 1)); ?>">Next</a>
                            </li>
                    </ul>
                    <span>Total <?php echo e($fo_data->lastPage()); ?> Pages</span>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
    function changeStatus(id) {
        console.log(id);
        var url = '/fochagestatus/' + id;
        window.location.href = url;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DB\JTC\resources\views/fo/activefo.blade.php ENDPATH**/ ?>