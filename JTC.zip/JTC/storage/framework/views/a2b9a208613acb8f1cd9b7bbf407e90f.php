<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Think of DG Think of DG- Login</title>
    <link rel="stylesheet" href="/login/style.css">
    


</head>


<body>
    <?php if(session('danger')): ?>
        <div style="display: flex; justify-content: center; padding:5px 10px">
            <p style="color: red"><?php echo e(session('danger')); ?></p>
        </div>
    <?php endif; ?>
    <section class="container">
        <div class="login-container">
            <div class="circle circle-one"></div>
            <div class="form-container">
                <img src="/login/illustration.png" alt="illustration" class="illustration" />
                <h1 class="opacity">LOGIN</h1>
                <form action="<?php echo e(route('adminloginpost')); ?> " method="POST">
                    <?php echo csrf_field(); ?>
                    <input name="email" type="email" placeholder="EMAIL" />
                    <?php if($errors->has('email')): ?>
                        <span style="color: red"><?php echo e($errors->first('email')); ?> </span>
                    <?php endif; ?>
                    <input name="password" type="password" placeholder="PASSWORD" />
                    <?php if($errors->has('password')): ?>
                        <span style="color: red"><?php echo e($errors->first('password')); ?> </span>
                    <?php endif; ?>
                    <button type="submit" class="opacity">SUBMIT</button>
                </form>
                <div class="register-forget opacity">
                    <a href="">FORGOT PASSWORD</a>
                </div>
            </div>
            <div class="circle circle-two"></div>
        </div>
        <div class="theme-btn-container"></div>
    </section>
</body>

<script src="/login/script.js"></script>



</html>
<?php /**PATH D:\DB\JTC\resources\views/admin/login.blade.php ENDPATH**/ ?>