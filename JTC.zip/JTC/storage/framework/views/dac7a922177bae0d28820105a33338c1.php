
<?php $__env->startSection('title'); ?>
Leads/all
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div>
    <div class="d-flex justify-content-end gap-2">
        <a class="btn btn-primary mb-4 " href="<?php echo e(route('addLeads')); ?>">Add Lead</a>
        <a href="<?php echo e(route('export')); ?>" class="btn btn-success mb-4">Export All leads</a>
    </div>
    
    <div class="box">
        <div class="box-header">
            <h3 class="box-title">All leads Data Table</h3>
        </div><!-- /.box-header -->
        <div class="box-body table-responsive">
            <table id="example2" class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>S.No.</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Address</th>
                        <th>Created Time </th>
                        <th>Remaining <small class="text-muted">minutes</small></th>
                        <th>Expiry <small class="text-muted">minutes</small></th>
                        <th>Status</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody>
                    <pre>

                        <?php
                        print_r($fo_data->toArray());
                        ?>
                        </pre>
                    
                    <?php $__currentLoopData = $fo_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $fo_leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($key + 1); ?></td>
                        

                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>


            </table>
            <div class="d-flex justify-content-end mt-2">
                <div>
                    <?php if($fo_data->lastPage() > 1): ?>
                    <ul class="pagination">
                        <li class="<?php echo e(($fo_data->currentPage() == 1) ? 'disabled' : ''); ?>">
                            <a class="btn btn-primary btn-sm me-1" href="<?php echo e($fo_data->url(1)); ?>">First</a>
                        </li>
                        <?php for($i = 1; $i <= $fo_data->lastPage(); $i++): ?>
                            <li class="">
                                <a class="btn btn-primary btn-sm me-1 <?php echo e(($fo_data->currentPage() == $i) ? 'active' : ''); ?>"
                                    href="<?php echo e($fo_data->url($i)); ?>"><?php echo e($i); ?></a>
                            </li>
                            <?php endfor; ?>

                            <li>
                                <a class="btn btn-primary btn-sm mx-1 <?php echo e(($fo_data->currentPage() == $fo_data->lastPage()) ? 'disabled' : ''); ?>"
                                    href="<?php echo e($fo_data->url($fo_data->currentPage() + 1)); ?>">Next</a>
                            </li>


                    </ul>
                    <span class="m-0">Total <?php echo e($fo_data->lastPage()); ?> Pages</span>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
    function changeStatus(id) {
        console.log(id);
        var url = '/leadschagestatus/' + id;
        window.location.href = url;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DB\JTC\resources\views/fo/foleads.blade.php ENDPATH**/ ?>