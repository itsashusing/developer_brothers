
<?php $__env->startSection('title'); ?>
Edit a Lead
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div>
    <div id="form" class="formbox">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title">Edit a lead</h3>
            </div>
            <form role="form" action="<?php echo e(route('editleads')); ?> " method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="box-body">
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <input type="text" name="id" hidden value="<?php echo e($lead->id); ?>" id="">
                                <label for="name">Name</label>
                                <input type="text" class="form-control" id="name" placeholder="Enter Name" name="name"
                                    value="<?php echo e($lead->name); ?>">
                                <?php if($errors->has('name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('name')); ?> </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="email">Email address</label>
                                <input type="email" class="form-control" id="email" placeholder="Enter email"
                                    name="email"  value="<?php echo e($lead->email); ?>">
                                <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?> </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="mobile">Mobile</label>
                                <input type="number" class="form-control" id="mobile" placeholder="Enter mobile number"
                                    name="mobile" " value="<?php echo e($lead->mobile); ?>">
                                <?php if($errors->has('mobile')): ?>
                                <span class="text-danger"><?php echo e($errors->first('mobile')); ?> </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="address">Address</label>
                                <input type="text" class="form-control" id="address" placeholder="Enter full Address "
                                    name="address" value="<?php echo e($lead->address); ?>">
                                <?php if($errors->has('address')): ?>
                                <span class="text-danger"><?php echo e($errors->first('address')); ?> </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">

                                <label for="fo">Select Fo</label>
                                <select id="fo" name="fo" class="form-select " aria-label="Small select example">
                                    <option selected>Select a fo</option>
                                    <?php $__currentLoopData = $fos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($fo->id); ?>"><?php echo e($fo->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                                <?php if($errors->has('fo')): ?>
                                <span class="text-danger"><?php echo e($errors->first('fo')); ?> </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">

                                <label for="time">Expiry time in minuts</label>
                                <input type="number" class="form-control" id="time" placeholder="Enter time in muinuts"
                                    name="time" value="<?php echo e($lead->time); ?>">
                                <?php if($errors->has('time')): ?>
                                <span class="text-danger"><?php echo e($errors->first('time')); ?> </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box-footer d-flex justify-content-end">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DB\JTC\resources\views/leads/editLead.blade.php ENDPATH**/ ?>