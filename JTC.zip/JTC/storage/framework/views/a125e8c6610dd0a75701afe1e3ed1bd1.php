
<?php $__env->startSection('title'); ?>
Edit Fo member
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div>
    <div id="form" class="formbox">
        <div class="box box-primary">
            <div class="box-header">
                <h3 class="box-title">Edit Fo</h3>
            </div>
            <form role="form" action="<?php echo e(route('editFo', $fo_data->id)); ?> " method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="box-body">
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <input type="text" name="id" hidden value="<?php echo e($fo_data->id); ?>" id="">
                                <label for="name">Name</label>
                                <input type="text" class="form-control" id="name" placeholder="Enter Name" name="name"
                                    value="<?php echo e($fo_data->name); ?>">
                                <?php if($errors->has('name')): ?>
                                <span class="text-danger"><?php echo e($errors->first('name')); ?> </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Email address</label>
                                <input type="email" class="form-control" id="exampleInputEmail1"
                                    placeholder="Enter email" name="email" value="<?php echo e($fo_data->email); ?>">
                                <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?> </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-6">

                            <div class="form-group">
                                <label for="adhar">Adhar Number</label>
                                <input type="text" id="adhar" class="form-control" placeholder="Enter Adhar Number"
                                    name="adhar" value="<?php echo e($fo_data->adhar); ?>">
                                <?php if($errors->has('adhar')): ?>
                                <span class="text-danger"><?php echo e($errors->first('adhar')); ?> </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="pan">Pan Number</label>
                                <input type="text" value="<?php echo e($fo_data->pan); ?>" id="pan" class="form-control"
                                    placeholder="Enter Pan Number" name="pan">
                                <?php if($errors->has('pan')): ?>
                                <span class="text-danger"><?php echo e($errors->first('pan')); ?> </span>
                                <?php endif; ?>
                            </div>

                        </div>

                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label for="mobile">Mobile</label>
                                <input type="text" class="form-control" id="mobile" placeholder="Enter mobile number"
                                    name="mobile" value="<?php echo e($fo_data->mobile); ?>">
                                <?php if($errors->has('mobile')): ?>
                                <span class="text-danger"><?php echo e($errors->first('mobile')); ?> </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label for="exampleInputPassword1">Password</label>
                                <input type="password" class="form-control" id="exampleInputPassword1"
                                    placeholder="Password Not required " name="password">
                                <?php if($errors->has('password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password')); ?> </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="box-footer d-flex justify-content-end">
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DB\JTC\resources\views/fo/editFo.blade.php ENDPATH**/ ?>